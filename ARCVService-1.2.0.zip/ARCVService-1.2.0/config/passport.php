<?php

return [

    'password_client' => env('PASSWORD_CLIENT', null),
    'password_client_secret' => env('PASSWORD_CLIENT_SECRET', null),

];
