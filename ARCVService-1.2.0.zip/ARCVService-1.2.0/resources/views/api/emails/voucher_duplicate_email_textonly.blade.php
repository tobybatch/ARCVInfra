* Voucher Duplicate Entered *

==============================================

[xXx]
Hi {{ config('mail.to_admin.name') }},

{{ $user }} has tried to submit voucher
{{ $vouchercode }} against
{{ $trader }} of
{{ $market }}'s account, however that voucher has already been submitted by another trader.

Thanks,
Rose Vouchers
[xXx]
==============================================

Alexandra Rose Charity

For more information please go to <a href="http://www.alexandrarose.org.uk/">www.alexandrarose.org.uk</a>.

<a href="http://www.alexandrarose.org.uk/privacy/">Privacy Policy</a>
