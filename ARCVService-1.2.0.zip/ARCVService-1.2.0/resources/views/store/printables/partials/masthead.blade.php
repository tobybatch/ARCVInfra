<div class="header">
	<img src="{{ asset('store/assets/logo.png') }}">
	<div class="print-notes">
		<p>Please do not photocopy blanks of this form to reuse.</p>
		<p>{{ $specificPrintNote }}</p>
	</div>
</div>
