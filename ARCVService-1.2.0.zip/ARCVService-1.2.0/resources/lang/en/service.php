<?php

return [

    'messages' => [
        'vouchers_create_success' => 'Created and activated :shortcode :start to :shortcode :end',
    ],
];
